-- MariaDB dump 10.17  Distrib 10.4.13-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: Sistema_tutorias
-- ------------------------------------------------------
-- Server version	10.4.13-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `calificaciones`
--

DROP TABLE IF EXISTS `calificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calificaciones` (
  `Parcial` int(11) NOT NULL,
  `Cal1` int(11) NOT NULL,
  `Cal2` int(11) NOT NULL,
  `Cal3` int(11) NOT NULL,
  `Cal4` int(11) NOT NULL,
  `Cal5` int(11) NOT NULL,
  `Cal6` int(11) NOT NULL,
  `Cal7` int(11) NOT NULL,
  `FechaRegistro` date NOT NULL,
  `Periodo` int(11) NOT NULL,
  `Usuario_Matricula` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calificaciones`
--

LOCK TABLES `calificaciones` WRITE;
/*!40000 ALTER TABLE `calificaciones` DISABLE KEYS */;
INSERT INTO `calificaciones` VALUES (1,7,8,8,9,7,5,8,'2020-10-20',2,'BSMO170909'),(1,7,8,10,5,9,5,8,'2020-10-20',2,'MPJO170808'),(1,7,4,9,7,9,9,8,'2020-10-20',2,'THIO190809'),(2,7,8,8,9,7,5,8,'2020-10-20',2,'BSMO170909'),(2,7,8,10,5,9,5,8,'2020-10-20',2,'MPJO170808'),(2,7,4,9,7,9,9,8,'2020-10-20',2,'THIO190809'),(3,9,8,8,9,9,8,9,'2020-10-21',2,'BSMO170909'),(3,10,9,8,6,9,9,8,'2020-10-21',2,'MPJO170808'),(3,8,8,9,7,9,9,9,'2020-10-21',2,'THIO190809');
/*!40000 ALTER TABLE `calificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita_tutoria`
--

DROP TABLE IF EXISTS `cita_tutoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita_tutoria` (
  `Id_tutoria` int(10) NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Asistencia` tinyint(4) NOT NULL,
  `Alumno` varchar(45) NOT NULL,
  `Disponibilidad_horario_Id` int(10) NOT NULL,
  PRIMARY KEY (`Id_tutoria`,`Disponibilidad_horario_Id`),
  KEY `fk_Cita_tutoria_Disponibilidad_horario1` (`Disponibilidad_horario_Id`),
  CONSTRAINT `fk_Cita_tutoria_Disponibilidad_horario1` FOREIGN KEY (`Disponibilidad_horario_Id`) REFERENCES `disponibilidad_horario` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita_tutoria`
--

LOCK TABLES `cita_tutoria` WRITE;
/*!40000 ALTER TABLE `cita_tutoria` DISABLE KEYS */;
INSERT INTO `cita_tutoria` VALUES (1,'2020-09-21',0,'GSLO170854',8),(2,'2020-09-30',0,'GSLO170854',9),(3,'2020-09-30',1,'GSLO170854',4),(7,'2020-09-28',1,'GSLO170854',10),(8,'2020-10-01',1,'GSLO170854',11),(9,'2020-10-07',0,'GSLO170854',4),(10,'2020-10-15',0,'GSLO170854',11),(11,'2020-10-19',0,'GSLO170854',10),(12,'2020-10-20',0,'THIO190809',2),(13,'2020-10-21',0,'GSLO170854',4),(14,'2020-10-20',0,'GSLO170854',12),(15,'2020-10-22',0,'GSLO170854',11),(17,'2020-10-22',0,'MPJO170808',13);
/*!40000 ALTER TABLE `cita_tutoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuestionario`
--

DROP TABLE IF EXISTS `cuestionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuestionario` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) NOT NULL,
  `Fecha` date NOT NULL,
  `Periodo` int(11) NOT NULL,
  `Usuario_Matricula` varchar(12) NOT NULL,
  PRIMARY KEY (`Id`,`Usuario_Matricula`),
  KEY `fk_Cuestionario_Usuario1_idx` (`Usuario_Matricula`),
  CONSTRAINT `fk_Cuestionario_Usuario1` FOREIGN KEY (`Usuario_Matricula`) REFERENCES `usuario` (`Matricula`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuestionario`
--

LOCK TABLES `cuestionario` WRITE;
/*!40000 ALTER TABLE `cuestionario` DISABLE KEYS */;
INSERT INTO `cuestionario` VALUES (7,'HABILIDADES DE ESTUDIO','2020-10-06',1,'DOLIVARES'),(8,'Hábitos de estudio ','2020-10-06',1,'DOLIVARES'),(9,'HABILIDADES DE ESTUDIO','2020-10-07',2,'LJIMENEZ'),(10,'Tutorias','2020-10-08',1,'DOLIVARES'),(11,'¿Qué te gusta hacer?','2020-10-18',1,'DOLIVARES'),(12,'Mensajes','2020-10-18',1,'DOLIVARES'),(13,'Estilos de aprendizaje','2020-10-21',2,'LJIMENEZ'),(14,'Reuniones','2020-10-21',2,'LJIMENEZ'),(15,'Reuniones2','2020-10-21',2,'LJIMENEZ'),(16,'hola','2020-10-21',2,'LJIMENEZ'),(17,'Joali','2020-10-21',2,'LJIMENEZ'),(18,'prueba','2020-10-21',2,'LJIMENEZ'),(19,'prueba1','2020-10-21',2,'LJIMENEZ'),(20,'prueba2','2020-10-21',2,'LJIMENEZ'),(21,'PruebaCuestionario','2020-10-21',2,'LJIMENEZ');
/*!40000 ALTER TABLE `cuestionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuestionario_preguntas`
--

DROP TABLE IF EXISTS `cuestionario_preguntas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuestionario_preguntas` (
  `Cuestionario_Id` int(11) NOT NULL,
  `Preguntas_cuestionario_Id` int(11) NOT NULL,
  PRIMARY KEY (`Cuestionario_Id`,`Preguntas_cuestionario_Id`),
  KEY `fk_Cuestionario_preguntas_Preguntas_cuestionario1_idx` (`Preguntas_cuestionario_Id`),
  CONSTRAINT `fk_Cuestionario_preguntas_Cuestionario1` FOREIGN KEY (`Cuestionario_Id`) REFERENCES `cuestionario` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Cuestionario_preguntas_Preguntas_cuestionario1` FOREIGN KEY (`Preguntas_cuestionario_Id`) REFERENCES `preguntas_cuestionario` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuestionario_preguntas`
--

LOCK TABLES `cuestionario_preguntas` WRITE;
/*!40000 ALTER TABLE `cuestionario_preguntas` DISABLE KEYS */;
INSERT INTO `cuestionario_preguntas` VALUES (7,2),(7,3),(7,4),(8,5),(8,6),(9,7),(9,8),(10,9),(10,10),(11,11),(11,12),(12,13),(12,14),(13,15),(13,16),(13,17),(14,18),(14,19),(15,20),(15,21),(16,22),(16,23),(17,24),(17,25),(18,26),(18,27),(19,28),(19,29),(20,30),(20,31),(21,32),(21,33);
/*!40000 ALTER TABLE `cuestionario_preguntas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disponibilidad_horario`
--

DROP TABLE IF EXISTS `disponibilidad_horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disponibilidad_horario` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Dia` int(4) NOT NULL,
  `Horario` time NOT NULL,
  `Usuario_Matricula` varchar(12) NOT NULL,
  PRIMARY KEY (`Id`,`Usuario_Matricula`),
  KEY `fk_Disponibilidad_horario_Usuario1_idx` (`Usuario_Matricula`),
  CONSTRAINT `fk_Disponibilidad_horario_Usuario1` FOREIGN KEY (`Usuario_Matricula`) REFERENCES `usuario` (`Matricula`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disponibilidad_horario`
--

LOCK TABLES `disponibilidad_horario` WRITE;
/*!40000 ALTER TABLE `disponibilidad_horario` DISABLE KEYS */;
INSERT INTO `disponibilidad_horario` VALUES (2,2,'11:30:00','LJIMENEZ'),(4,3,'13:00:00','DOLIVARES'),(6,5,'12:20:00','LJIMENEZ'),(8,1,'09:00:00','DOLIVARES'),(9,3,'16:00:00','DOLIVARES'),(10,1,'08:03:00','DOLIVARES'),(11,4,'15:00:00','DOLIVARES'),(12,2,'13:05:00','DOLIVARES'),(13,4,'14:00:00','LJIMENEZ');
/*!40000 ALTER TABLE `disponibilidad_horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domicilio`
--

DROP TABLE IF EXISTS `domicilio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `domicilio` (
  `Calle` varchar(45) NOT NULL,
  `NumE` int(4) DEFAULT NULL,
  `NumI` int(4) DEFAULT NULL,
  `Colonia` varchar(45) NOT NULL,
  `Municipio` varchar(45) DEFAULT NULL,
  `Estado` int(11) NOT NULL,
  `CodigoP` varchar(45) NOT NULL,
  `Usuario_Matricula` varchar(12) NOT NULL,
  PRIMARY KEY (`Usuario_Matricula`),
  KEY `fk_Domicilio_Usuario_idx` (`Usuario_Matricula`),
  CONSTRAINT `fk_Domicilio_Usuario` FOREIGN KEY (`Usuario_Matricula`) REFERENCES `usuario` (`Matricula`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domicilio`
--

LOCK TABLES `domicilio` WRITE;
/*!40000 ALTER TABLE `domicilio` DISABLE KEYS */;
INSERT INTO `domicilio` VALUES ('Avenida 6 este',6,14,'Kovas','Jiutepec',5,'62500','BNHJ170897'),('Tulipanes',5,0,'Otilio Montaño','Jiutepec',17,'63459','GSLO170854'),('Boulevard Alta tensión Residencial Las Palmas',0,418,'Villas de Xochitepec','Xochitepec',17,'62790','MPJO170808'),('Jazmín',4,3,'Arboledas del monte','Tulancingo',13,'23456','THIO190809');
/*!40000 ALTER TABLE `domicilio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eventos`
--

DROP TABLE IF EXISTS `eventos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventos` (
  `IdEvento` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) NOT NULL,
  `Ruta` varchar(70) NOT NULL,
  `Url` varchar(100) NOT NULL,
  PRIMARY KEY (`IdEvento`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventos`
--

LOCK TABLES `eventos` WRITE;
/*!40000 ALTER TABLE `eventos` DISABLE KEYS */;
INSERT INTO `eventos` VALUES (5,'Upemor5','calidad5.jpg','http://www.transparenciamorelos.mx/otis/UPEMOR'),(6,'Convocatoria 2020','convocatoria.jpg','https://www.upemor.edu.mx/documentos/2020/enero/Convocatoria2020.pdf'),(7,'Pandemia','pandemia.jpg','https://www.eluniversal.com.mx/mundo/coronavirus-eu-dice-que-pandemia-ha-entrado-una-nueva-fase'),(10,'prueba','images (5).jpg','https://es.stackoverflow.com/questions/1983/c%C3%B3mo-enviar-una-imagen-o-archivo-fijo-a-un-input-fi'),(11,'Nueo','Colorera.jpg','http://localhost/phpmyadmin/sql.php?db=sistema_tutorias&table=cita_tutoria&pos=0');
/*!40000 ALTER TABLE `eventos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formato_tutorias`
--

DROP TABLE IF EXISTS `formato_tutorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formato_tutorias` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Campo` varchar(45) NOT NULL,
  `Activo` tinyint(4) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formato_tutorias`
--

LOCK TABLES `formato_tutorias` WRITE;
/*!40000 ALTER TABLE `formato_tutorias` DISABLE KEYS */;
INSERT INTO `formato_tutorias` VALUES (1,'Asunto',1),(2,'Descripción del alumno',1),(3,'Solución',1),(4,'Instancia para canalizar el asunto',1),(5,'Persona en cargo',0);
/*!40000 ALTER TABLE `formato_tutorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formatotutorias_respuestas`
--

DROP TABLE IF EXISTS `formatotutorias_respuestas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formatotutorias_respuestas` (
  `Respuesta` varchar(120) NOT NULL,
  `Formato_tutorias_Id` int(11) NOT NULL,
  `Cita_tutoria_Id_tutoria` int(10) NOT NULL,
  PRIMARY KEY (`Formato_tutorias_Id`,`Cita_tutoria_Id_tutoria`),
  KEY `fk_FormatoTutorias_respuestas_Formato_tutorias1_idx` (`Formato_tutorias_Id`),
  KEY `fk_FormatoTutorias_respuestas_Cita_tutoria1_idx` (`Cita_tutoria_Id_tutoria`),
  CONSTRAINT `fk_FormatoTutorias_respuestas_Cita_tutoria1` FOREIGN KEY (`Cita_tutoria_Id_tutoria`) REFERENCES `cita_tutoria` (`Id_tutoria`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_FormatoTutorias_respuestas_Formato_tutorias1` FOREIGN KEY (`Formato_tutorias_Id`) REFERENCES `formato_tutorias` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formatotutorias_respuestas`
--

LOCK TABLES `formatotutorias_respuestas` WRITE;
/*!40000 ALTER TABLE `formatotutorias_respuestas` DISABLE KEYS */;
INSERT INTO `formatotutorias_respuestas` VALUES ('w',1,3),('Problemas con materias',1,8),('w',2,3),('Ha tenido problemas de salud',2,8),('w',3,3),('Presentar justificantes en la dirección ',3,8),('w',4,3),('Dirección de IIF',4,8);
/*!40000 ALTER TABLE `formatotutorias_respuestas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notificaciones` (
  `Matricula_tutor` varchar(14) NOT NULL,
  `Fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificaciones`
--

LOCK TABLES `notificaciones` WRITE;
/*!40000 ALTER TABLE `notificaciones` DISABLE KEYS */;
INSERT INTO `notificaciones` VALUES ('LJIMENEZ','2020-10-21');
/*!40000 ALTER TABLE `notificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodo`
--

DROP TABLE IF EXISTS `periodo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periodo` (
  `IdPeriodo` int(10) NOT NULL AUTO_INCREMENT,
  `Grado` int(11) NOT NULL,
  `Grupo` varchar(5) NOT NULL,
  `Periodo` varchar(45) NOT NULL,
  `AnoGrupo` int(8) NOT NULL,
  `Activo` tinyint(4) NOT NULL,
  `TutorMatricula` varchar(12) NOT NULL,
  PRIMARY KEY (`IdPeriodo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodo`
--

LOCK TABLES `periodo` WRITE;
/*!40000 ALTER TABLE `periodo` DISABLE KEYS */;
INSERT INTO `periodo` VALUES (1,5,'A','Otoño',2020,1,'DOLIVARES'),(2,6,'A','Otoño',2020,1,'LJIMENEZ');
/*!40000 ALTER TABLE `periodo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preguntas`
--

DROP TABLE IF EXISTS `preguntas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preguntas` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Pregunta` varchar(60) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preguntas`
--

LOCK TABLES `preguntas` WRITE;
/*!40000 ALTER TABLE `preguntas` DISABLE KEYS */;
/*!40000 ALTER TABLE `preguntas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preguntas_cuestionario`
--

DROP TABLE IF EXISTS `preguntas_cuestionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preguntas_cuestionario` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Pregunta` varchar(45) NOT NULL,
  `Respuesta1` varchar(45) NOT NULL,
  `Respuesta2` varchar(45) NOT NULL,
  `Respuesta3` varchar(45) DEFAULT NULL,
  `Respuesta4` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preguntas_cuestionario`
--

LOCK TABLES `preguntas_cuestionario` WRITE;
/*!40000 ALTER TABLE `preguntas_cuestionario` DISABLE KEYS */;
INSERT INTO `preguntas_cuestionario` VALUES (2,'Problemas con materias','Ha tenido problemas de salud','Presentar justificantes en la dirección ','Dirección de IIF','11111'),(3,'f','222','222','r','r'),(4,'f','kkk','kkk','kkk','r'),(5,'x','x','x','x','x'),(6,'x','x','x','x','x'),(7,'3','3','3','3',''),(8,'1','1','1','',''),(9,'Problemas con materias','q','q','q',''),(10,'Resolución','4','4','',''),(11,'a','a','a','a','a'),(12,'b','b','b','b','b'),(13,'c','c','c','c','c'),(14,'d','d','d','d','d'),(15,'¿Donde estudias?','Mi recamara','En la sala','En el patio',''),(16,'¿Escuchas música mientras estudias?','Si','No','',''),(17,'¿Te mueves mucho mientras estudias?','Si ','No','Mas o menos',''),(18,'1','1','1','1','1'),(19,'2','2','2','2','2'),(20,'1','1','1','1','1'),(21,'1','1','1','1','1'),(22,'1','1','1','1','1'),(23,'1','1','1','1','1'),(24,'2','2','2','2','2'),(25,'2','2','2','2','2'),(26,'1','1','1','1','1'),(27,'1','1','1','1',''),(28,'1','1','1','1','1'),(29,'1','1','1','1','1'),(30,'1','1','1','1','1'),(31,'1','1','1','1','1'),(32,'1','1','1','1','1'),(33,'1','1','1','1','1');
/*!40000 ALTER TABLE `preguntas_cuestionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respuesta`
--

DROP TABLE IF EXISTS `respuesta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `respuesta` (
  `Respuesta_Id` int(11) NOT NULL,
  `Alumno` varchar(15) NOT NULL,
  `Valor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respuesta`
--

LOCK TABLES `respuesta` WRITE;
/*!40000 ALTER TABLE `respuesta` DISABLE KEYS */;
INSERT INTO `respuesta` VALUES (15,'BSMO170909',2),(16,'BSMO170909',1),(17,'BSMO170909',1),(15,'THIO190809',3),(16,'THIO190809',2),(17,'THIO190809',3),(15,'MPJO170808',1),(16,'MPJO170808',2),(17,'MPJO170808',1);
/*!40000 ALTER TABLE `respuesta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `Matricula` varchar(12) NOT NULL,
  `Nombre` varchar(25) NOT NULL,
  `ApellidoP` varchar(25) NOT NULL,
  `ApellidoM` varchar(25) DEFAULT NULL,
  `FechaN` date NOT NULL,
  `TipoUsuario` int(2) NOT NULL,
  `Contrasena` varchar(200) NOT NULL,
  `PrimerInicio` tinyint(4) NOT NULL,
  PRIMARY KEY (`Matricula`),
  UNIQUE KEY `Matricula` (`Matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES ('AAVILA','Andrea','Avila','Pérez','1993-02-18',2,'26cce910553aab2708990a1b3f5aee6f',1),('Admin1','Daniel','Olivares','Lázaro','1996-02-09',1,'admin',1),('Admin123','Lizeth','Pedraza','Martínez','2020-09-09',1,'Admin123',1),('Admin3','Felipe de Jesús','Martínez','López','1972-02-05',1,'Admin3',1),('Admin4','de','ddd','ddd','2020-09-03',1,'fba54f07332ad667fce71ac27e82b0a7',1),('BNHJ170897','Benito','Martínez','López','1998-03-05',3,'61a3f438fd35d26be1fb4fbb2986df7c',1),('BSMO170909','Mónica','Brito','Sánchez','2000-01-08',3,'ef0697ef9530ccdb1708e6e2777f26df',1),('DOLIVARES','Daniel','Olivares','Lázaro','1996-02-09',2,'dan',1),('GSLO170854','Lizeth','García','Pérez','1999-12-12',3,'f511dfde6344e9d750cc3d9df58fd004',1),('LJIMENEZ','Laura','Jiménez','Pérez','1970-04-29',2,'lauri',1),('MPJO170808','Joali','Martínez','Pedraza','1994-07-25',3,'joali123',0),('PGARDUNO','Paola','Garduño','Pedraza','1988-02-27',2,'PGARDUNO',0),('THIO190809','Silvia','Pedraza','Ovando','2002-03-14',3,'456c25db1cf9ccdc4c097b4b20e2e8f4',1);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_periodo`
--

DROP TABLE IF EXISTS `usuario_periodo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_periodo` (
  `Periodo_IdPeriodo` int(10) NOT NULL,
  `Usuario_Matricula` varchar(12) NOT NULL,
  PRIMARY KEY (`Periodo_IdPeriodo`,`Usuario_Matricula`),
  KEY `fk_Usuario_periodo_Usuario1_idx` (`Usuario_Matricula`),
  CONSTRAINT `fk_Usuario_periodo_Periodo1` FOREIGN KEY (`Periodo_IdPeriodo`) REFERENCES `periodo` (`IdPeriodo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Usuario_periodo_Usuario1` FOREIGN KEY (`Usuario_Matricula`) REFERENCES `usuario` (`Matricula`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_periodo`
--

LOCK TABLES `usuario_periodo` WRITE;
/*!40000 ALTER TABLE `usuario_periodo` DISABLE KEYS */;
INSERT INTO `usuario_periodo` VALUES (1,'BNHJ170897'),(1,'GSLO170854'),(2,'BSMO170909'),(2,'MPJO170808'),(2,'THIO190809');
/*!40000 ALTER TABLE `usuario_periodo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_pregunta`
--

DROP TABLE IF EXISTS `usuario_pregunta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_pregunta` (
  `Preguntas_Id` int(11) NOT NULL,
  `Usuario_Matricula` varchar(12) NOT NULL,
  `Respuesta` varchar(45) NOT NULL,
  PRIMARY KEY (`Preguntas_Id`,`Usuario_Matricula`),
  KEY `fk_Usuario_pregunta_Usuario1_idx` (`Usuario_Matricula`),
  CONSTRAINT `fk_Usuario_pregunta_Preguntas1` FOREIGN KEY (`Preguntas_Id`) REFERENCES `preguntas` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Usuario_pregunta_Usuario1` FOREIGN KEY (`Usuario_Matricula`) REFERENCES `usuario` (`Matricula`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_pregunta`
--

LOCK TABLES `usuario_pregunta` WRITE;
/*!40000 ALTER TABLE `usuario_pregunta` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_pregunta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-21 10:36:02
